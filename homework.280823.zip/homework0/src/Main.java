public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("hello my name is Adil");
        System.out.printf("my name is %s,i am %d,i weight %.1f","adil",27,66.5);
    }
}